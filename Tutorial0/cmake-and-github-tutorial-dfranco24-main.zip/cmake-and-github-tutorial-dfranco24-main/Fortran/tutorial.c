#include "tutorial_src/tutorial.h"

// Return rank of process
int tutorial() 
{
    int val;
    extern int tutorial_f(int* val);
    tutorial_f(&val);
    return val;
}


