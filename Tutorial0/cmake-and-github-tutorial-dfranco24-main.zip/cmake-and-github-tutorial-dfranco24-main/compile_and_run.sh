mkdir build
cd build

