# CMake and Github Tutorial

## Initialize Github Repositories
1. Download this repository with 'git clone https://github.com/ProfessorBienz/cmake\_tutorial.git'
2. Create a new branch called 'develop' and do steps 3-15 in the develop branch
3. Add the following submodule https://github.com/ProfessorBienz/tutorial_src_shell.git
4. Initialize and update the submodule 

## Edit CMakeLists.txt
1. Create a CMakeLists.txt in the outermost folder
2. Require at least CMake 3.15
3. Require C standard 99 and C++ standard 11
4. Fetch the content to install googletest with FetchContent.
    - GIT\_REPOSITORY = https://github.com/google/googletest.git
    - GIT\_TAG = 5376968f6948923e2411081fd9372e71a59d8e77
5. Make the fetched content available, and enable testing
6. Add the subdirectory \<submodule\_folder\_name\>
    - This will fill the variable src\_SOURCES with the appropriate files that should be included in your library
6. Create a library called 'tutorial' containing the files in the src\_SOURCES variable.
7. Link the math library (libm) with target\_link\_libraries
8. Add the subdirectory \<submodule\_folder\_name\>/tests

## Test Your Code Locally
13. Edit the file compile\_and\_run.sh to compile and test your code:
    - Add submodule initialization and update lines to this file:
    - Create a build folder
    - From within the build folder, run cmake ('cmake ..')
    - Compile the code ('make')
14. Run the unit tests to ensure everything is working (e.g. 'make test')

## Make Sure Binaries Are Not Uploaded To Github
15. Edit the .gitignore file to ignore any build files

## Push Changes to Github 
16. Merge the develop branch into the master branch.  Keep the develop branch as is.
17. Push both the master and develop branches back to Github 

## Check Github Classroom Results
18. Go to www.github.com
19. Select your cmake\_tutorial repository
20. Click the 'Actions' tab
21. Check that tests are passing 


# Language of Choice
For this tutorial, you can use C, C++, Fortran, or Python.  Make sure to follow the additional requirements for your language of choice, below.

## Additional C/C++ Requirments
1. The 'tutorial' library should also include the following files:
    - C/tutorial.c
2. Edit the file C/tutorial.c to return 0 to pass the unit tests

## Additional Fortran Requirements
1. Your CMakeLists.txt must enable the language Fortran
2. The 'tutorial' library should also include the following files:
    - Fortran/tutorial.c
    - Fortran/tutorial.f90
3. Edit the file Fortran/tutorial.f90 to return 0 to pass the unit tests

## Additional Python Requirements
1. Your CMakeLists.txt must find the package PythonLibs using find\_package.  Set this as REQUIRED.
2. You must include the directories in the variable PYTHON\_INCLUDE\_DIRS using the include\_directories function.
3. The 'tutorial' library should also include the following files:
    - Python/tutorial.c
4. Set your PYTHONPATH to include the directory ${CMAKE\_SOURCE\_DIR}/Python.  This directory can be found by adding the following to your CMakeLists.txt:
    - message("Add ${CMAKE\_SOURCE\_DIR}/Python to PYTHONPATH")
5. Edit the file Python/tutorial.py to return 0 to pass the unit tests
