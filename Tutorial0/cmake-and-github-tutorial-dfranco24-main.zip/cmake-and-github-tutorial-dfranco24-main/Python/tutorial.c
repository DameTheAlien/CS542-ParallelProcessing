// https://docs.python.org/3/extending/embedding.html

#include "tutorial_src/tutorial.h"

#include <Python.h>

void initialize()
{
    Py_Initialize();
}

void finalize()
{
    Py_Finalize();
}

// Return 0
int tutorial() 
{
    PyObject *pName, *pModule, *pFunc;
    PyObject *pValue;
    int val = -1;
    static int i;

    // Initialize Python Interpreter
    if (i == 0)
    {
        initialize();
        atexit(finalize);
        ++i;
    }

    // Find file
    pName = PyUnicode_DecodeFSDefault("tutorial");
    pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Find function within file
        pFunc = PyObject_GetAttrString(pModule, "tutorial_py");

        if (pFunc && PyCallable_Check(pFunc))
        {
            pValue = PyObject_CallObject(pFunc, NULL);
            if (pValue != NULL)
            {
                val = PyLong_AsLong(pValue);
                Py_DECREF(pValue);
            }
            else 
            {
                Py_DECREF(pFunc);
                Py_DECREF(pModule);
                PyErr_Print();
                printf("Call Failed\n");
                return 1;
            }
        }
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            printf("Cannot find function %s\n", "tutorial_py");
        }

        Py_DECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        printf("Failed to locate file %s\n", "tutorial");
    }

    // Finalize Python Interpreter
    //Py_Finalize();

    return val;
}





