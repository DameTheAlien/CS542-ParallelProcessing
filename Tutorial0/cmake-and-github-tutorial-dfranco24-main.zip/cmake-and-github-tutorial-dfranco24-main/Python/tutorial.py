from mpi4py import MPI

def tutorial_py():
    return -1

