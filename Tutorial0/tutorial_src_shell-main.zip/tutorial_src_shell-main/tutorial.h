#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>


#ifdef __cplusplus
extern "C"
{
#endif

int tutorial(); 

#ifdef __cplusplus
}
#endif
